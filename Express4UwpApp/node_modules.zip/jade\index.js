
module.exports = require('./lib/jade');
