0.1.3 / 2014-07-06
==================

  * Better array support
  * Improved support for trailing slash in non-ending mode

0.1.0 / 2014-03-06
==================

  * add options.end

0.0.2 / 2013-02-10
==================

  * Update to match current express
  * add .license property to component.json
