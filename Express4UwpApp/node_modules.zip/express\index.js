
module.exports = require('./lib/express');
